package com.street.spring.action;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.awt.*;

@Controller
@RequestMapping("/springTest")
public class SpringTestAction {

	@RequestMapping(value = "helloSpring", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
	public String helloSpring() {
		String result = null;
		try {
			result = HttpClientUtils.get("https://api.zhuishushenqi.com/ranking/gender");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}
}
